<table cellpadding="3">
<tr>
	<td> <strong>Benutzer</strong></td>	<td><strong>Gruppe</strong></td>	<td><strong>Rechte</strong></td>
</tr>
<tr>
	<td> Antragsteller</td>	<td>user</td>	<td>Rechte 1</td>
</tr>
<tr>
	<td> Bestandsaufnahme (BA)</td>	<td>umzugsteam</td>	<td>Rechte 1</td>
</tr>
<tr>
	<td> Property</td>	<td>kunde_report</td>	<td>Rechte 2</td>
</tr>
<tr>
	<td> Property + BA</td>	<td>kunde_report</td>	<td>Rechte 3</td>
</tr>
<tr>
	<td> Admin Standort</td>	<td>admin_standort</td>	<td>Rechte 3</td>
</tr>
<tr>
	<td> Admin Gesamt</td>	<td>admin_gesamt</td>	<td>Rechte 7</td>
</tr>
<tr>
	<td> Admin</td>	<td>admin</td>	<td>Rechte 7</td>
</tr>
</table>
