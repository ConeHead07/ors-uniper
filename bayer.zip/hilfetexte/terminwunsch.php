<?php require("../header.php"); ?>
<strong>Hinweis zur Vorlaufzeit</strong><br>
Bitte beachten Sie, dass f�r die Bearbeitung
von Umzugsantr�gen eine Vorlaufzeit von 
8 Werktagen ben�tigt wird.<br>
