<?php 

$ConfRegData['user'] = 'user.inc.php';
$ConfRegData['stamm_abteilungen'] = 'stamm_abteilungen.inc.php';
$ConfRegData['stamm_immobilien'] = 'stamm_immobilien.inc.php';
$ConfRegData['stamm_mitarbeiter'] = 'stamm_mitarbeiter.inc.php';
$ConfRegData['cms_bereiche'] = 'cms_bereiche.inc.php';
$ConfRegData['umzugsantrag'] = 'umzugsantrag.inc.php';
$ConfRegData['umzugsanlagen'] = 'umzugsanlagen.inc.php';
$ConfRegData['umzugsmitarbeiter'] = 'umzugsmitarbeiter.inc.php';
$ConfRegData['stamm_standorte'] = 'stamm_standorte.inc.php';
$ConfRegData['todoes'] = 'todoes.inc.php';
$ConfRegData['raumkategorien'] = 'raumkategorien.inc.php';
$ConfRegData['raumtypen'] = 'raumtypen.inc.php';
$ConfRegData['stamm_hauptabteilungen'] = 'stamm_hauptabteilungen.inc.php';
$ConfRegData['gf'] = 'gf.inc.php';
$ConfRegData['gebaeude'] = 'gebaeude.inc.php';
$ConfRegData['nebenleistungen'] = 'nebenleistungen.inc.php';
$ConfRegData['nebenleistungsanlagen'] = 'nebenleistungsanlagen.inc.php';
$ConfRegData['lieferfirmen'] = 'lieferfirmen.inc.php';
$ConfRegData['dienstleister'] = 'dienstleister.inc.php';
$ConfRegData['lm'] = 'lm.inc.php';
$ConfRegData['leistungskatalog'] = 'leistungskatalog.inc.php';
$ConfRegData['leistungskategorie'] = 'leistungskategorie.inc.php';
$ConfRegData['leistungsmatrix'] = 'leistungsmatrix.inc.php';

?>