<?php 

function umzugsantrag_check_status($fN, $arrInput, $arrConf, $err) {
	echo "<div style=\"border:1px solid #f00\">";
	echo print_r($fN,1);
	echo print_r($arrInput,1);
	echo print_r($arrConf,1);
	echo print_r($err,1);
	echo "</div>";
}

