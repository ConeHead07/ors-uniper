<?php 

function mitarbeiter_check_extern_firma() {
	return true;
}

?>
