<?php 

function fbmail($to, $su, $bo, $hd) {
	global $aSmtpConn;
	global $aHeader;
	
	if (empty($aSmtpConn) || !class_exists("fbsmtp")) {
            if (is_scalar($to)) return mail($to, $su, $bo, $hd);
            else return false;
	}
        
	$aHdLines = explode("\n", $hd);
	$aUserHeader = $aHeader;
	for ($i = 0; $i < count($aHdLines); $i++) {
            $t = explode(":", $aHdLines[$i]);
            $k = trim(array_shift($t));
            $aUserHeader[$k] = implode(":", $t);
	}
	
	// START: TESTVERSAND
	$show_status = false;
	if (is_scalar($to)) $arrayTo[0] = array("email" => "<".$to.">", "anrede" => "");
	else if (isset($to["email"]) || isset($to[0]["email"])) $arrayTo = $to;
	else if (isset($to["to"]))  { $arrayTo = $to; $arrayTo["email"]=$to["to"]; }
	else if (isset($to[0]["to"])) { $arrayTo = $to; foreach($arrayTo as $k => $v) $arrayTo[$k]["email"] = $arrayTo[$k]["to"]; }
	else return false;
//	echo '<pre>#' . __LINE__ . ' ' . print_r($arrayTo,1) . '</pre>' . PHP_EOL;
        
	if ($_SERVER["HTTP_HOST"]=="localhost" || $_SERVER["HTTP_HOST"]=="127.0.0.1") {
            $li = 1;
            $logfile = __DIR__ . '/../log/fbmail_'.date('YmdHis').".txt";
            while(file_exists($logfile)) {
                $logfile = __DIR__ . '/../log/fbmail_'.date('YmdHis')."(".(++$li).").txt";
            }
            file_put_contents($logfile, print_r(array('arrayTo'=>$arrayTo,'su'=>$su,'bo'=>$bo, 'aUserHeader'=>$aUserHeader),1));
            return true;
        }
        
	$MoveSmtp = new fbsmtp($aSmtpConn);
	$ckckSendmail = $MoveSmtp->send($arrayTo, $su, $bo, $aUserHeader, $show_status);
	return $ckckSendmail;
	
	if($ckckSendmail) {
		echo "E-Mails wurden verschickt";
	} else {
		echo "Beim Versenden der E-Mails ist ein Fehler aufgetreten!";
	}
	// ENDE: TESTVERSAND
}

function fbmail_multipart($to, $su, $bo, $hd) {
	global $aSmtpConn;
	global $aHeader;
	if (strpos(__FILE__, 'staging') !== false) {
		return false;
	}
	
	if (empty($aSmtpConn) || !class_exists("fbsmtp")) {
		
		if (is_scalar($to)) return mail($to, $su, $bo, $hd);
		else return false;
	}
	
	$aHdLines = explode("\n", $hd);
	$aUserHeader = $aHeader;
	for ($i = 0; $i < count($aHdLines); $i++) {
		if (!trim($aHdLines[$i])) break;
		
		$t = explode(":", $aHdLines[$i]);
		$k = trim(array_shift($t));
		$aUserHeader[$k] = implode(":", $t);
	}
	$aUserHeader["multipart_data"] = $hd;
	//echo "<pre>#".__LINE__." ".basename(__FILE__)." ".print_r($aUserHeader,1)."</pre><br>\n";
	
	// START: TESTVERSAND
	$show_status = false;
	//$aHeader["From"] = "\"Move-Management\"<move@mertens.ag>";
	if (is_scalar($to)) $arrayTo[0] = array("email" => "<".$to.">", "anrede" => "");
	else if (isset($to["email"]) || isset($to[0]["email"])) $arrayTo = $to;
	else return false;
	
	$MoveSmtp = new fbsmtp($aSmtpConn);
	
	//echo "#".__LINE__." ".basename(__FILE__)." arrayTo:".print_r($arrayTo,1)."<br>\n";
	//return 1;
	
	$ckckSendmail = $MoveSmtp->send($arrayTo, $su, $bo, $aUserHeader, $show_status);
	return $ckckSendmail;
	
	if($ckckSendmail) {
		echo "E-Mails wurden verschickt";
	} else {
		echo "Beim Versenden der E-Mails ist ein Fehler aufgetreten!";
	}
	// ENDE: TESTVERSAND
}

if (basename(__FILE__)==basename($_SERVER["PHP_SELF"])) {
	require_once("../header.php");
	$to = "frank.barthold@gmail.com";
	$su = "Hallo Testmail von ".$_SERVER["HTTP_HOST"];
	$bo = "Hallo ...";
	$hd = "Reply-To: frank.barthold@googlemail.com";
	$show_status = true;
	if (fbmail($to, $su, $bo, $hd, $show_status)) {
		echo "Mail wurde verschickt!<br>\n";
	} else {
		echo "Mail konnte nicht verschickt werden!<br>\n";
	}
	echo "fbmail($to, $su, $bo, $hd)<br>\n";
}
?>