<?php

define('DB_DUSS',  'mt_move_bayer');
define('DB_DUSS_HOST', 'localhost:3308');
define('DB_DUSS_USER', 'root');
define('DB_DUSS_PASS', 'geheim3');  // geheim3
define('APP_ENVIRONMENT', 'PRODUKTION'); // 'PRODUKTION' // 'DEVELOPMENT'