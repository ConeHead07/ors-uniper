function menuHiOn() { return false; }
function gotoMenuLink(obj) { return false; }
